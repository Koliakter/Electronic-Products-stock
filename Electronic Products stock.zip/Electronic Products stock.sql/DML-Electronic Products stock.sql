----DML---
Use Electronic_Products_Stock
Go
----INSERT DATA--Table-1.Customer
Insert Into Customer(Cust_ID,Cust_Name,Cust_Address,Phone)
	VALUES
			(1,'Md.Moin Uddin','Dhaka',			01925874169),
			(2,'Mr.Siraj Khan','Tagail',		01925874161),
			(3,'Mr.Saiman','Shavar',			01925874162),
			(4,'Miss.Afrian Begum','Nabijco',	01925874163),
			(5,'Mr.Moniruddin','Shiraj gonge',	01925874164),
			(6,'Mir khoka','Gazipur',			01925874165),
			(7,'Abu Afran','Dhanmindi',			01925874166),
			(8,'Mohon khan','Cummilla',			01925874167),
			(9,'Mr. Roni Ahamed','Rangpur',		01925874168),
			(10,'Md.Sobu','Khulna',				01925874199);
go
----INSERT DATA--Table-2.Stock
Insert Into Stock(St_ID,St_Name)
Values
		(1,	'Electronics');			
go
----INSERT DATA--Table-3.Product
Insert Into Product(Pro_ID,Pro_Name,Quantity,Price)
		Values
			(1,	'LED TV',		2000,	32000),
			(2,	'COMPUTER',		5000,	48000),
			(3,	'MOUSE',		5000,	3000),
			(4,	'KEY BOARD',	5000,	2000),
			(5,	'LCD MONITOR',	1000,	2500),
			(6,	'SOUND BAR',	9000,	6000),
			(7,	'AIR COOLER',	7000,	23000),
			(8,	'AIR CONDITON',	3000,	70000),
			(9,	'REFTIGERATOR',	4000,	38000),
			(10,	'DVD',		5000,	5000);

go
----INSERT DATA--References Table-4.Product_Details- 
Insert Into Product_Details(Cust_ID,St_ID,Pro_ID,catagoryid)
	Values	(1,	1,1,1),
			(2,	1,2,2),
			(3,	1,3,3),
			(4,	1,4,4),
			(5,	1,5,5),
			(6,	1,6,6),
			(7,	1,7,7),
			(8,	1,8,8),
			(9,	1,9,9),
			(10	,1,10,10);
go
----INSERT DATA--Table-5.catagory
insert into catagory ( catagoryid,catagoryName)
values(1,'A'),
	  (2,'Best'),
	  (3,'C'),
	  (4,'D'),
	  (5,'G'),
	  (6,'B'),
	  (7,'J'),
	  (8,'E'),
	  (9,'Best'),
	  (10,'F');
go
select*from catagory
----INSERT DATA--Table-6.Stock_Audit
Insert into Stock_Audit(Product_ID,Product_Name,St_Name,DoneBy,ActivityTime)
Values  (1,'LED TV',       'Electronics', 'Polash','01/01/2020 05:00'),
		(2,	'COMPUTER',    'Electronics', 'Polash','02/01/2020 05:00'),
		(3,	'MOUSE',       'Electronics', 'Polash','03/01/2020 05:00'),
		(4,	'KEY BOARD',   'Electronics', 'Arif',  '05/01/2020 05:00'),
		(5,	'KEY BOARD',   'Electronics', 'Arif',  '06/01/2020 05:00'),
		(6,	'LCD MONITOR', 'Electronics', 'Arif',  '06/01/2020 05:00'),
		(7,	'SOUND BAR',   'Electronics', 'shamim','06/01/2020 05:00'),
		(8,	'AIR COOLER',  'Electronics', 'shamim','06/01/2020 05:00'),
		(9,	'REFTIGERATOR','Electronics','shamim','06/01/2020 05:00'),
		(10, 'PHONE',      'Electronics','shamim','06/01/2020 05:00');
go
----Use Select Statement
Select * from Product;
Select * from Stock;
Select * from Customer;
Select * from Product_Details;
Select * from catagory;
Select * from Stock_Audit;
go
---inner join query-2 table--
Select * from Product;
Select * from Stock;

select product.Pro_ID,product.Pro_Name, catagory.catagoryName
from product inner join catagory
on product.Pro_ID=catagory.catagoryid;
-----left join query---
select product.Pro_ID,product.Pro_Name, catagory.catagoryName
from product left join catagory
on product.Pro_ID=catagory.catagoryid;
-----right join query---
select product.Pro_ID,product.Pro_Name, catagory.catagoryName
from product right join catagory
on product.Pro_ID=catagory.catagoryid;

------Join-show Electronics Product Stock Quentity & Queantity*Total Price>800000--Using Groupby-
Select Product.Pro_Name,Stock.St_Name,Product.Quantity,Product.Price,
Sum(Product.Quantity*Product.Price) As Total_Price
From Product_Details 
JOIN Stock On Stock.St_ID=Product_Details.St_ID
JOIN Product On Product.Pro_ID=Product_Details.Pro_ID
Group by
Stock.St_Name,Product.Pro_Name,Product.Quantity,Product.Price
Having SUM(Product.Quantity*Product.Price)>80000
Order by Total_Price;
--------
select  * from Stock_Audit
--------------COUNT---------------------
SELECT COUNT(*) as "Number of Rows"
FROM Stock_Audit;

Select * from Product;
--------------COUNT---------------------
SELECT COUNT(Price) as [Number of Rows]
FROM Product;
--------------AVG---------------------
SELECT AVG (Price) as [AVG_Price]
FROM Product;
--------------SUM---------------------
SELECT sum(Price) as [Tota_Price]
FROM Product;
--------------max--------------------
SELECT Max(Price) as [Max_Price]
FROM Product;
---------------min--------------------
SELECT Min(Price) as [Min_Price]
FROM Product;
---------------GROUP BY--------------------
Select * from Customer;
SELECT COUNT(Cust_ID) as [number], CusT_Address
FROM Customer
GROUP BY CusT_Address;

---------------ROLLUP--------------------
Select * from Product;
SELECT COUNT(Pro_ID) as [ID], Price
FROM Product
GROUP BY ROLLUP (Price);
------------grouping sets--------------------
SELECT Pro_ID, Quantity,Price
FROM Product
GROUP BY grouping sets (Pro_ID, Quantity,Price);
---------Cast--------
Select * from Stock_Audit
Update  Stock_Audit set Activity = getdate();
----Cast Convert------
Select * from Stock_Audit
select datetime = convert (datetime,'06 January 2020 05:00');
----Sub Query----Show customer categories count
Select Customer.Cust_Name, Count (Cust_Name) As Categories
From Customer 
JOIN Product_Details On Customer.Cust_ID=Product_Details.Cust_ID
Where Cust_Name IN (Select Cust_Name from Customer)
Group by Customer.Cust_Name;

-----Case Function----Define Product Price Range
Select  Product.Pro_Name, Product.Price,
Case
When Product.Price<5000 Then 'Low price'
When Product.Price <15000 Then 'Mid Price'
Else 'High price'
End as Comments
from Product
Join Product_Details on Product.Pro_ID = Product_Details.Pro_ID;
------------Update---------------
Create Proc Sp_Product_Update
	@Pro_ID INT,
	@Pro_Name Varchar(50)
AS
Update Product 
	SET Pro_Name=@Pro_Name
    WHERE Pro_ID=@Pro_ID
EXEC Sp_Product_Update 7,'Signal pattener Ganerator'
-------------Delete------------
Create Proc Sp_Product_Delete
@Pro_ID INT
AS
DELETE FROM Product WHERE Pro_ID=@Pro_ID
Go
EXEC Sp_Product_Delete 8

-- table expesstion(CTE)--
Select * from Product;
WITH All_Pro (Pro_Name,Quantity,Price)AS 
( SELECT  Pro_Name,Quantity,Price
FROM Product p
JOIN Product_Details On p.Pro_ID=Product_Details.Cust_ID
)
select * from All_Pro 
--------------------End---------------------




