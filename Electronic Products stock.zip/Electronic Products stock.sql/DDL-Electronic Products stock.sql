----Drop Statement Use-
Drop database Electronic_Products_Stock;
Drop table Product;
Drop table Customer;
Drop table Stock;
Drop table Product_Details;
Drop table Stock_Audit;
Go
------- DDL----- 
----Create database
CREATE DATABASE Electronic_Products_Stock
ON primary 
(
	NAME= 'Electronic_Products_Stock',
	FILENAME= 'C:\Program Files\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQL\DATA\ Electronic_Products_Stock.mdf',
	SIZE=25MB,
	MAXSIZE=100MB,
	FILEGROWTH=5%
)
LOG ON
(
	NAME='Electronic_Products_Stock_Log',
	FILENAME='C:\Program Files\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQL\DATA\Electronic_Products_Stock_Log.ldf',
	SIZE=5MB,
	MAXSIZE=50MB,
	FILEGROWTH=1%
);
Use Electronic_Products_Stock;
-----Create Table-1.Customer
Create table Customer
(
	Cust_ID int primary key,
	Cust_Name Varchar (50),
	Cust_Address Varchar (50),
	Phone int
);
-----Create Table-2.Product
Create table Product
(
	Pro_ID int primary key,
	Pro_Name Varchar (50),
	Quantity Int,
	Price Money
);
---Create Table-3.Stock
Create table Stock
(
	St_ID int primary key not null,
	St_Name Varchar (50)
);
-----Create Table-4.catagory
create table catagory
(
catagoryid int primary key not null,
catagoryName varchar(50) 
);
---Create Table-5.Product_Details
Create table Product_Details
(
	Cust_ID int references Customer(Cust_ID),
	St_ID int references Stock(St_ID),
	Pro_ID int references Product(Pro_ID),
	catagoryid int references catagory(catagoryid)
);
-----Create Table-6.Stock_Audit
Create table Stock_Audit
(
Product_ID int primary key,
Product_Name Varchar (50),
St_Name varchar(50),
Activity Datetime,
DoneBy varchar(20),
ActivityTime datetime
);
----Index
Create Nonclustered Index Pro_ID On Product (Pro_ID);
-----Merge row-------
Create table tbl_Customers_temp
(
Cust_ID int primary key,
Cust_Name Nvarchar (50),
Cust_Address Varchar (50),
Phone int
);
-------Create & Insert store procedure
 Create Proc Sp_Product
				 @Pro_ID Int,
				 @Pro_Name Varchar(20),
				 @Quantity Int,
				 @Price Money
As
 Insert into Product(Pro_ID,Pro_Name,Price,Quantity)
 values (@Pro_ID,@Pro_Name,@Quantity,@Price)
Go
Exec Sp_Product 11,CCTV,4,1500000
Go
------------VIEW-----------
Create View V_AllProduct As
Select Customer.Cust_Name,Product.Pro_Name,Stock.St_Name,Product.Quantity,Product.Price,
Sum(Product.Quantity*Product.Price)AS TotalPrice
From Customer 
JOIN Product_Details On Customer.Cust_ID=Product_Details.Cust_ID
JOIN Stock On Stock.St_ID=Product_Details.St_ID
JOIN Product On Product.Pro_ID=Product_Details.Pro_ID
Group by Customer.Cust_Name,Stock.St_Name,Product.Pro_Name,
Product.Quantity,Product.Price
Having Sum(Product.Quantity*Product.Price)<>0
Go
Select * From V_AllProduct
-------------------------UDF(User define function)--------
------------ table- value function--------
create function dbo.TFn_Stock()
returns table
return								
SELECT  Customer.Cust_Name,Stock.St_Name,Product.Pro_Name,
Product.Quantity,Product.Price
From Customer 
JOIN Product_Details On Customer.Cust_ID=Product_Details.Cust_ID
JOIN Stock On Stock.St_ID=Product_Details.St_ID
JOIN Product On Product.Pro_ID=Product_Details.Pro_ID
Group by Customer.Cust_Name,Stock.St_Name,Product.Pro_Name,
Product.Quantity,Product.Price
Having Sum(Product.Quantity*Product.Price)<>0
Select * from dbo.TFn_Stock()
----------SCALER VALUE FUNCTION
Create Function Fn_Stock()
Returns int
As
Begin
Declare @Stocks int;
Set @Stocks = (select count(Customer.Cust_ID) AS [Categories]
From Product_Details 
join Customer on Customer.Cust_ID = Product_Details.Cust_ID
Where Cust_Name = 'Mohon khan' 
group by Product_Details.Cust_ID, Customer.Cust_Name)
Return @Stocks;
End;
Go
Select  dbo.Fn_Stock()
Go
----------multi statement table-valued function----------
Select * from Stock
Select * from Product;
go

create function dbo.MFn_Stock()
Returns @outTable table(Pro_ID int,Quantity int, Price money, Add_Price money)
begin
insert into @outTable(Pro_ID,Quantity, Price,Add_Price)
select Pro_ID,Quantity,Price,Price = Price+10
from Product
return
end;
select * from  dbo.MFn_Stock();
---Create Trigger & RAISERROR
--create an instead of trigger to rise an error if any try to update an delete more than one record as a time
---- 
CREATE TRIGGER dbo.Trg_InsteadOfUpdate_Product
ON dbo.Product_Details
INSTEAD OF UPDATE

AS
BEGIN
DECLARE @Pro_ID Int,@Cust_ID int, @St_ID int
SELECT @Pro_ID = inserted.Pro_ID,
@Cust_ID = inserted.Cust_ID,
@St_ID = inserted.St_ID
FROM inserted
if UPDATE(Pro_ID)
BEGIN
RAISERROR('This ProductID Unchanging .', 16 ,1)
ROLLBACK
END
ELSE
BEGIN
UPDATE [Product_Details]
SET Pro_ID = @Pro_ID
Where St_ID  = @St_ID 
END
END
update Product_Details set Pro_ID = 3 where St_ID = 1
--------End--------------------------

